const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');

const currentScoreEl = document.getElementById('currentScore');
const highScoreEl = document.getElementById('highScore');
const multiplierEl = document.getElementById('scoreMultiplier');
const speedSlider = document.getElementById('speedSlider');
const speedVal = document.getElementById('speedVal');
const soundToggleBtn = document.getElementById('soundToggleBtn');

const startScreen = document.getElementById('startScreen');
const gameOverScreen = document.getElementById('gameOverScreen');
const startBtn = document.getElementById('startBtn');
const restartBtn = document.getElementById('restartBtn');
const finalScoreEl = document.getElementById('finalScore');

const upBtn = document.getElementById('upBtn');
const downBtn = document.getElementById('downBtn');
const leftBtn = document.getElementById('leftBtn');
const rightBtn = document.getElementById('rightBtn');

const GRID_SIZE = 20;
const TILE_COUNT = canvas.width / GRID_SIZE;

let snake = [];
let velocity = { x: 0, y: 0 };
let food = { x: 0, y: 0, config: null };
let score = 0;
let highScore = localStorage.getItem('neonSnakeHighScore') || 0;
let gameInterval = null;
let gameSpeed = 100; 
let isRunning = false;
let isPaused = false;
let soundEnabled = true;
let particles = [];
let nextVelocity = { x: 0, y: 0 };

// Advanced Features: Multiplier & Combo Tracker
let currentMultiplier = 1;
let foodEatenStreak = 0;

highScoreEl.textContent = highScore;

// Web Audio API Synthesizer (No external mp3 files needed! Sound effects generated live)
let audioCtx = null;
function initAudio() {
    if (!audioCtx) {
        audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    }
}

function playSound(type) {
    if (!soundEnabled) return;
    initAudio();
    if (!audioCtx) return;

    const osc = audioCtx.createOscillator();
    const gainNode = audioCtx.createGain();
    osc.connect(gainNode);
    gainNode.connect(audioCtx.destination);

    const now = audioCtx.currentTime;

    if (type === 'eat') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(300, now);
        osc.frequency.exponentialRampToValueAtTime(800, now + 0.1);
        gainNode.gain.setValueAtTime(0.2, now);
        gainNode.gain.exponentialRampToValueAtTime(0.01, now + 0.1);
        osc.start(now);
        osc.stop(now + 0.1);
    } else if (type === 'powerup') {
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(500, now);
        osc.frequency.exponentialRampToValueAtTime(1200, now + 0.2);
        gainNode.gain.setValueAtTime(0.3, now);
        gainNode.gain.exponentialRampToValueAtTime(0.01, now + 0.2);
        osc.start(now);
        osc.stop(now + 0.2);
    } else if (type === 'gameover') {
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(200, now);
        osc.frequency.linearRampToValueAtTime(50, now + 0.4);
        gainNode.gain.setValueAtTime(0.3, now);
        gainNode.gain.exponentialRampToValueAtTime(0.01, now + 0.4);
        osc.start(now);
        osc.stop(now + 0.4);
    }
}

// Food types with color, points and effects
const FOOD_TYPES = [
    { color: '#ff0055', points: 10, glow: '#ff0055', type: 'normal' }, 
    { color: '#00ff66', points: 20, glow: '#00ff66', type: 'bonus' }, 
    { color: '#ffea00', points: 50, glow: '#ffea00', type: 'multiplier' } // Special Multiplier Booster Pellet
];

class Particle {
    constructor(x, y, color) {
        this.x = x;
        this.y = y;
        this.color = color;
        this.size = Math.random() * 4 + 2;
        const angle = Math.random() * Math.PI * 2;
        const speed = Math.random() * 3 + 1;
        this.vx = Math.cos(angle) * speed;
        this.vy = Math.sin(angle) * speed;
        this.alpha = 1;
        this.decay = Math.random() * 0.03 + 0.02;
    }

    update() {
        this.x += this.vx;
        this.y += this.vy;
        this.alpha -= this.decay;
    }

    draw(ctx) {
        ctx.save();
        ctx.globalAlpha = Math.max(this.alpha, 0);
        ctx.fillStyle = this.color;
        ctx.shadowColor = this.color;
        ctx.shadowBlur = 8;
        ctx.fillRect(this.x, this.y, this.size, this.size);
        ctx.restore();
    }
}

function initGame() {
    snake = [
        { x: 10, y: 10 },
        { x: 9, y: 10 },
        { x: 8, y: 10 }
    ];
    velocity = { x: 1, y: 0 };
    nextVelocity = { x: 1, y: 0 };
    score = 0;
    currentMultiplier = 1;
    foodEatenStreak = 0;
    multiplierEl.textContent = currentMultiplier + 'x';
    currentScoreEl.textContent = score;
    particles = [];
    spawnFood();
}

function spawnFood() {
    let valid = false;
    while (!valid) {
        food.x = Math.floor(Math.random() * TILE_COUNT);
        food.y = Math.floor(Math.random() * TILE_COUNT);
        
        valid = true;
        for (let part of snake) {
            if (part.x === food.x && part.y === food.y) {
                valid = false;
                break;
            }
        }
    }
    const rand = Math.random();
    if (rand > 0.85) {
        food.config = FOOD_TYPES[2]; // Gold Multiplier Pellet
    } else if (rand > 0.6) {
        food.config = FOOD_TYPES[1]; // Green Bonus Pellet
    } else {
        food.config = FOOD_TYPES[0]; // Pink Standard Pellet
    }
}

function createExplosion(gridX, gridY, color) {
    const pixelX = gridX * GRID_SIZE + GRID_SIZE / 2;
    const pixelY = gridY * GRID_SIZE + GRID_SIZE / 2;
    for (let i = 0; i < 18; i++) {
        particles.push(new Particle(pixelX, pixelY, color));
    }
}

function startGame() {
    startScreen.classList.add('hidden');
    gameOverScreen.classList.add('hidden');
    initGame();
    isRunning = true;
    isPaused = false;
    if (gameInterval) clearInterval(gameInterval);
    gameInterval = setInterval(gameLoop, gameSpeed);
}

function triggerGameOver() {
    isRunning = false;
    clearInterval(gameInterval);
    playSound('gameover');
    finalScoreEl.textContent = score;
    
    if (score > highScore) {
        highScore = score;
        localStorage.setItem('neonSnakeHighScore', highScore);
        highScoreEl.textContent = highScore;
    }
    
    gameOverScreen.classList.remove('hidden');
}

function gameLoop() {
    if (isPaused) return;

    velocity = nextVelocity;
    const head = { x: snake[0].x + velocity.x, y: snake[0].y + velocity.y };

    if (head.x < 0 || head.x >= TILE_COUNT || head.y < 0 || head.y >= TILE_COUNT) {
        triggerGameOver();
        return;
    }

    for (let part of snake) {
        if (head.x === part.x && head.y === part.y) {
            triggerGameOver();
            return;
        }
    }

    snake.unshift(head);

    if (head.x === food.x && head.y === food.y) {
        // Score calculation with multiplier
        const pointsEarned = food.config.points * currentMultiplier;
        score += pointsEarned;
        currentScoreEl.textContent = score;

        // Sound & Particle feedback
        if (food.config.type === 'multiplier') {
            currentMultiplier = Math.min(currentMultiplier + 1, 5); // Max 5x multiplier
            multiplierEl.textContent = currentMultiplier + 'x';
            playSound('powerup');
        } else {
            playSound('eat');
        }

        createExplosion(food.x, food.y, food.config.color);
        spawnFood();
    } else {
        snake.pop();
    }

    draw();
}

function draw() {
    ctx.fillStyle = 'rgba(8, 7, 17, 0.4)';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    ctx.strokeStyle = 'rgba(255, 255, 255, 0.015)';
    ctx.lineWidth = 1;
    for (let i = 0; i < TILE_COUNT; i++) {
        ctx.beginPath();
        ctx.moveTo(i * GRID_SIZE, 0);
        ctx.lineTo(i * GRID_SIZE, canvas.height);
        ctx.stroke();

        ctx.beginPath();
        ctx.moveTo(0, i * GRID_SIZE);
        ctx.lineTo(canvas.width, i * GRID_SIZE);
        ctx.stroke();
    }

    // Draw Food with Glowing Animation
    const time = Date.now() * 0.008;
    const pulseSize = Math.sin(time) * 2 + (GRID_SIZE / 2 - 2);
    
    ctx.save();
    ctx.shadowColor = food.config.glow;
    ctx.shadowBlur = 15;
    ctx.fillStyle = food.config.color;
    ctx.beginPath();
    ctx.arc(
        food.x * GRID_SIZE + GRID_SIZE / 2,
        food.y * GRID_SIZE + GRID_SIZE / 2,
        Math.max(pulseSize, 4),
        0,
        Math.PI * 2
    );
    ctx.fill();
    ctx.restore();

    // Draw Snake
    snake.forEach((part, index) => {
        ctx.save();
        const isHead = index === 0;
        ctx.shadowColor = '#00f3ff';
        ctx.shadowBlur = isHead ? 15 : 8;
        ctx.fillStyle = isHead ? '#ffffff' : '#00f3ff';
        
        const padding = isHead ? 1 : 2;
        ctx.fillRect(
            part.x * GRID_SIZE + padding,
            part.y * GRID_SIZE + padding,
            GRID_SIZE - padding * 2,
            GRID_SIZE - padding * 2
        );
        ctx.restore();
    });

    // Draw Particles
    for (let i = particles.length - 1; i >= 0; i--) {
        particles[i].update();
        particles[i].draw(ctx);
        if (particles[i].alpha <= 0) {
            particles.splice(i, 1);
        }
    }
}

function changeDirection(dir) {
    if (!isRunning || isPaused) return;
    switch (dir) {
        case 'UP':
            if (velocity.y === 0) nextVelocity = { x: 0, y: -1 };
            break;
        case 'DOWN':
            if (velocity.y === 0) nextVelocity = { x: 0, y: 1 };
            break;
        case 'LEFT':
            if (velocity.x === 0) nextVelocity = { x: -1, y: 0 };
            break;
        case 'RIGHT':
            if (velocity.x === 0) nextVelocity = { x: 1, y: 0 };
            break;
    }
}

// Live Speed Slider Control (Updates speed instantly)
speedSlider.addEventListener('input', e => {
    gameSpeed = parseInt(e.target.value);
    
    // Update label text based on speed value
    if (gameSpeed <= 60) speedVal.textContent = "Insane";
    else if (gameSpeed <= 90) speedVal.textContent = "Fast";
    else if (gameSpeed <= 120) speedVal.textContent = "Normal";
    else speedVal.textContent = "Slow";

    if (isRunning && !isPaused) {
        clearInterval(gameInterval);
        gameInterval = setInterval(gameLoop, gameSpeed);
    }
});

// Sound Toggle Button
soundToggleBtn.addEventListener('click', () => {
    soundEnabled = !soundEnabled;
    soundToggleBtn.textContent = soundEnabled ? "🔊 SOUND: ON" : "🔇 SOUND: OFF";
    soundToggleBtn.style.borderColor = soundEnabled ? "#ff0055" : "#666";
});

// Keyboard Input
window.addEventListener('keydown', e => {
    if (['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.code)) {
        e.preventDefault();
    }

    if (e.code === 'Space') {
        if (isRunning) isPaused = !isPaused;
        return;
    }

    switch (e.code) {
        case 'ArrowUp':
        case 'KeyW': changeDirection('UP'); break;
        case 'ArrowDown':
        case 'KeyS': changeDirection('DOWN'); break;
        case 'ArrowLeft':
        case 'KeyA': changeDirection('LEFT'); break;
        case 'ArrowRight':
        case 'KeyD': changeDirection('RIGHT'); break;
    }
});

// Touch UI Buttons
upBtn.addEventListener('click', () => changeDirection('UP'));
downBtn.addEventListener('click', () => changeDirection('DOWN'));
leftBtn.addEventListener('click', () => changeDirection('LEFT'));
rightBtn.addEventListener('click', () => changeDirection('RIGHT'));

// Canvas Swipe Support
let touchStartX = 0;
let touchStartY = 0;

canvas.addEventListener('touchstart', e => {
    if (!isRunning || isPaused) return;
    touchStartX = e.touches[0].clientX;
    touchStartY = e.touches[0].clientY;
    e.preventDefault();
}, { passive: false });

canvas.addEventListener('touchend', e => {
    if (!isRunning || isPaused) return;
    let touchEndX = e.changedTouches[0].clientX;
    let touchEndY = e.changedTouches[0].clientY;

    let diffX = touchEndX - touchStartX;
    let diffY = touchEndY - touchStartY;

    if (Math.abs(diffX) > Math.abs(diffY)) {
        if (diffX > 20) changeDirection('RIGHT');
        else if (diffX < -20) changeDirection('LEFT');
    } else {
        if (diffY > 20) changeDirection('DOWN');
        else if (diffY < -20) changeDirection('UP');
    }
    e.preventDefault();
}, { passive: false });

startBtn.addEventListener('click', startGame);
restartBtn.addEventListener('click', startGame);

draw();
