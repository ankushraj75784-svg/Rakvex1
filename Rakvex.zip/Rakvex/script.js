/**
 * RAKVEX — Modern Browser Gaming Platform
 * Pure Vanilla JavaScript: High-performance, Accessible, Zero-Dependency
 */

document.addEventListener('DOMContentLoaded', () => {
  'use strict';

  // 1. DOM SELECTORS
  const header = document.getElementById('header');
  const mobileToggleBtn = document.getElementById('mobile-toggle');
  const navMenu = document.getElementById('nav-menu');
  const navLinks = document.querySelectorAll('.nav-link');

  const searchOpenBtn = document.getElementById('search-open-btn');
  const searchCloseBtn = document.getElementById('search-close-btn');
  const searchModal = document.getElementById('search-modal');
  const searchBackdrop = document.getElementById('search-backdrop');
  const gameSearchInput = document.getElementById('game-search-input');
  const searchResultsContainer = document.getElementById('search-results');

  const filterButtons = document.querySelectorAll('.filter-btn');
  const gameCards = document.querySelectorAll('.game-card');
  const categoryLinks = document.querySelectorAll('[data-cat-filter]');

  // 2. STICKY HEADER SCROLL EFFECT
  const handleScroll = () => {
    if (window.scrollY > 20) {
      header.classList.add('scrolled');
    } else {
      header.classList.remove('scrolled');
    }
  };
  window.addEventListener('scroll', handleScroll, { passive: true });
  handleScroll();

  // 3. RESPONSIVE MOBILE NAVIGATION TOGGLE
  if (mobileToggleBtn && navMenu) {
    mobileToggleBtn.addEventListener('click', () => {
      const isExpanded = mobileToggleBtn.getAttribute('aria-expanded') === 'true';
      mobileToggleBtn.setAttribute('aria-expanded', String(!isExpanded));
      navMenu.classList.toggle('mobile-open');
    });

    // Close menu when a navigation anchor is clicked
    navLinks.forEach(link => {
      link.addEventListener('click', () => {
        mobileToggleBtn.setAttribute('aria-expanded', 'false');
        navMenu.classList.remove('mobile-open');
      });
    });
  }

  // 4. ACTIVE LINK OBSERVER ON SCROLL
  const sections = document.querySelectorAll('section[id], header[id]');
  const observerOptions = {
    root: null,
    rootMargin: '-20% 0px -70% 0px',
    threshold: 0
  };

  const navObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const id = entry.target.getAttribute('id');
        navLinks.forEach(link => {
          if (link.getAttribute('href') === `#${id}`) {
            link.classList.add('active');
          } else {
            link.classList.remove('active');
          }
        });
      }
    });
  }, observerOptions);

  sections.forEach(sec => navObserver.observe(sec));

  // 5. FEATURED GAMES CATEGORY FILTER
  const applyFilter = (category) => {
    // Update active class on filter pill buttons
    filterButtons.forEach(btn => {
      if (btn.getAttribute('data-filter') === category) {
        btn.classList.add('active');
      } else {
        btn.classList.remove('active');
      }
    });

    // Filter games
    gameCards.forEach(card => {
      const cardCategory = card.getAttribute('data-category');
      if (category === 'all' || cardCategory === category) {
        card.style.display = 'flex';
      } else {
        card.style.display = 'none';
      }
    });
  };

  filterButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      const targetCategory = btn.getAttribute('data-filter');
      applyFilter(targetCategory);
    });
  });

  // Category cards trigger corresponding featured filter & smooth scroll
  categoryLinks.forEach(catCard => {
    catCard.addEventListener('click', (e) => {
      const filter = catCard.getAttribute('data-cat-filter');
      if (filter) {
        applyFilter(filter);
      }
    });
  });

  // 6. SEARCH MODAL & INSTANT FILTERING
  const allGamesDataset = [
    { title: 'Snake', category: 'Arcade', path: '/games/snake/', ready: true },
    { title: '2048', category: 'Puzzle', path: '/games/2048/', ready: true },
    { title: 'Tic Tac Toe', category: 'Brain', path: '/games/tic-tac-toe/', ready: true },
    { title: 'Memory Match', category: 'Brain', path: '/games/memory-match/', ready: true },
    { title: 'Minesweeper', category: 'Puzzle', path: '/games/minesweeper/', ready: true },
    { title: 'Reaction Time Test', category: 'Brain', path: '/games/reaction-time/', ready: true },
    { title: 'Bubble Shooter', category: 'Arcade', path: '#', ready: false },
    { title: 'Block Puzzle', category: 'Casual', path: '#', ready: false }
  ];

  const renderSearchResults = (query = '') => {
    const cleanQuery = query.toLowerCase().trim();
    const matches = allGamesDataset.filter(game => 
      game.title.toLowerCase().includes(cleanQuery) || 
      game.category.toLowerCase().includes(cleanQuery)
    );

    if (matches.length === 0) {
      searchResultsContainer.innerHTML = `
        <div style="padding: 1.5rem; text-align: center; color: var(--text-dim); font-size: 0.9rem;">
          No matching games found for "${escapeHtml(query)}"
        </div>
      `;
      return;
    }

    searchResultsContainer.innerHTML = matches.map(game => `
      <a href="${game.path}" class="search-item" ${!game.ready ? 'onclick="alert(\'This game is currently in active development. Stay tuned for launch!\'); return false;"' : ''}>
        <div class="search-item-info">
          <span class="search-item-title">${escapeHtml(game.title)}</span>
          <span class="search-item-cat">${escapeHtml(game.category)}</span>
        </div>
        <span style="font-size: 0.75rem; color: ${game.ready ? 'var(--accent-cyan)' : 'var(--text-dim)'}; font-weight: 700;">
          ${game.ready ? 'PLAY &rarr;' : 'COMING SOON'}
        </span>
      </a>
    `).join('');
  };

  const openSearch = () => {
    searchModal.classList.add('open');
    searchModal.setAttribute('aria-hidden', 'false');
    gameSearchInput.value = '';
    renderSearchResults('');
    setTimeout(() => gameSearchInput.focus(), 60);
  };

  const closeSearch = () => {
    searchModal.classList.remove('open');
    searchModal.setAttribute('aria-hidden', 'true');
    gameSearchInput.blur();
  };

  if (searchOpenBtn) searchOpenBtn.addEventListener('click', openSearch);
  if (searchCloseBtn) searchCloseBtn.addEventListener('click', closeSearch);
  if (searchBackdrop) searchBackdrop.addEventListener('click', closeSearch);

  // Keyboard Navigation: Esc to close, Ctrl+K or Cmd+K to open
  window.addEventListener('keydown', (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
      e.preventDefault();
      openSearch();
    } else if (e.key === 'Escape' && searchModal.classList.contains('open')) {
      closeSearch();
    }
  });

  if (gameSearchInput) {
    gameSearchInput.addEventListener('input', (e) => {
      renderSearchResults(e.target.value);
    });
  }

  // Helper XSS Safe sanitizer
  function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }
});